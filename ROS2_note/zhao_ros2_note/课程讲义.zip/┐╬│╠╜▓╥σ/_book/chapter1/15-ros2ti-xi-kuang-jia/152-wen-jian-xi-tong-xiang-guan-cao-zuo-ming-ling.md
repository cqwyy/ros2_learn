### 1.5.2 文件系统相关操作命令

apt-cache search



