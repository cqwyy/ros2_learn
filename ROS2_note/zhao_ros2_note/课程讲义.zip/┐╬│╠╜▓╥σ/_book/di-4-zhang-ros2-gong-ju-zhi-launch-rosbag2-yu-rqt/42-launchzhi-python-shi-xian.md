## 4.2 launch之Python实现

本节主要介绍launch文件的Python实现语法。

