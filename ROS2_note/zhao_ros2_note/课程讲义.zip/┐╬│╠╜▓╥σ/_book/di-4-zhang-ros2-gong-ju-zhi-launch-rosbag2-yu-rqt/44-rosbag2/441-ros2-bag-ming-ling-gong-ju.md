### 4.4.1 ros2 bag 命令工具

在 ROS2 中提供了 ros2 bag 命令工具，可以方便的实现数据的录制回放等操作，ros2 bag 的基本使用语法如下：

```
convert  给定一个 bag 文件，写出一个新的具有不同配置的 bag 文件；
info     输出 bag 文件的相关信息；
list     输出可用的插件信息；
play     回放 bag 文件数据；
record   录制 bag 文件数据；
reindex  重建 bag 的元数据文件。
```



