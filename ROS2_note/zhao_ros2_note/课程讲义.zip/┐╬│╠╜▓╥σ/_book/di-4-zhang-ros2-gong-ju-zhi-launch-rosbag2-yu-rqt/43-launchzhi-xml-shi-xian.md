## 4.3 launch之xml、yaml实现

本节主要介绍 launch 文件的 xml 与 yaml 实现语法。xml 与 yaml 实现语法雷同，所以本节会将二者集合在一起介绍。

