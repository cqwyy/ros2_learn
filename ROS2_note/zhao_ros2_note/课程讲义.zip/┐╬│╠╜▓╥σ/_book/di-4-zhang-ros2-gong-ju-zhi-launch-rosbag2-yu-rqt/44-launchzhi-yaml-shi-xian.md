## 4.4 launch之yaml实现

本节主要介绍launch文件的yaml实现语法。

