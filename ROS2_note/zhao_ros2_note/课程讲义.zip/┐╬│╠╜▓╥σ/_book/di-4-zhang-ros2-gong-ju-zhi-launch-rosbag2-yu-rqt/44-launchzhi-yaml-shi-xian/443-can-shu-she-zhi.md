### 4.4.3 参数设置

**需求：**启动turtlesim\_node节点时，可以动态设置背景色。

**示例：**

在 cpp01\_launch/launch/yaml 目录下新建 yaml03\_args.launch.yaml 文件，输入如下内容：

