### 4.4.5 分组设置

**需求：**对 launch 文件中的多个 Node 进行分组。

**示例：**

在 cpp01\_launch/launch/yaml 目录下新建 yaml05\_group.launch.yaml 文件，输入如下内容：

