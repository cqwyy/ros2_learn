### 4.4.4 文件包含

**需求：**新建 launch 文件，包含 4.2.3 中的 launch 文件并为之传入设置背景色相关的参数。

**示例：**

在 cpp01\_launch/launch/yaml 目录下新建 yaml04\_include.launch.yaml 文件，输入如下内容：

