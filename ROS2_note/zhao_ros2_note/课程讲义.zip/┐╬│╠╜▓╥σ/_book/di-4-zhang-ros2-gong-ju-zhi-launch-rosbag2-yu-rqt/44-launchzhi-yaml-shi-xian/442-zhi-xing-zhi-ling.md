### 4.4.2 执行指令

**需求：**在 launch 文件中执行 ROS2 命令，以简化部分功能的调用。

**示例：**

在 cpp01\_launch/launch/yaml 目录下新建 yaml02\_cmd.launch.yaml 文件，输入如下内容：

