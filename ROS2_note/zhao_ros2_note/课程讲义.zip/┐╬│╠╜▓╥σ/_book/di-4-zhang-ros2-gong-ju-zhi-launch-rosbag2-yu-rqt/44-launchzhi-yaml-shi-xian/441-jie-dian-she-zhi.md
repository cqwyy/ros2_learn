### 4.4.1 节点设置

**需求：**launch 文件中配置节点的相关属性。

**示例：**

在 cpp01\_launch/launch/yaml 目录下新建 yaml01\_node.launch.yaml 文件，输入如下内容：

