from launch import LaunchDescription
from launch_ros.actions import Node
# 封装终端指令相关类--------------
# from launch.actions import ExecuteProcess
# from launch.substitutions import FindExecutable
# 参数声明与获取-----------------
# from launch.actions import DeclareLaunchArgument
# from launch.substitutions import LaunchConfiguration
# 文件包含相关-------------------
# from launch.actions import IncludeLaunchDescription
# from launch.launch_description_sources import PythonLaunchDescriptionSource
# 分组相关----------------------
# from launch_ros.actions import PushRosNamespace
# from launch.actions import GroupAction
# 事件相关----------------------
# from launch.event_handlers import OnProcessStart, OnProcessExit
# from launch.actions import ExecuteProcess, RegisterEventHandler,LogInfo
# 获取功能包下share目录路径-------
from ament_index_python.packages import get_package_share_directory
import os

""" 
    需求：演示 Node 的使用。
    
    构造函数参数说明：

        :param: package 被执行的程序所属的功能包；T
        :param: executable 可执行程序；T
        :param: name 节点名称；T
        :param: namespace 设置命名空间；T
        :param: remappings 实现话题重映射；T
        :param: arguments 为节点传参；T
                          xx yy zz --ros-args

        :param: ros_arguments 为节点传参；F
                          --ros-args xx yy
        :param: exec_name 设置程序标签；F
        :param: parameters 设置参数；F

"""

def generate_launch_description():
    # turtle1 = Node(
    #     package="turtlesim",
    #     executable="turtlesim_node",
    #     exec_name="my_label",
    #     ros_arguments=["--remap","__ns:=/t2"]
    #     # ros2 run turtlesim turtlesim_node --ros-args --remap __ns:=/t1
    #     )
    turtle2 = Node(
        package="turtlesim",
        executable="turtlesim_node",
        respawn=True,
        name="haha",
        # 方式1，直接设置参数
        # parameters=[{"background_r": 255,"background_g": 0,"background_b": 0}]
        # 方式2(更常用)，读取yaml文件(通过yaml文件的绝对路径读取)
        # parameters=["/home/ros2/ws02_tools/install/cpp01_launch/share/cpp01_launch/config/haha.yaml"]
        # 优化:动态获取路径
        parameters=[os.path.join(get_package_share_directory("cpp01_launch"),"config","haha.yaml")]

    )
    
    return LaunchDescription([turtle2])